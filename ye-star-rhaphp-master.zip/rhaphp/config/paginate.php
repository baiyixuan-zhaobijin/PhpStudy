<?php
return [
    'type'      => '\app\behavior\Layui',
    'var_page'  => 'page',
    'list_rows' => 15,
];