<?php
require_once "lib/WxPay.Api.php";
require_once "lib/wxPay.php";
require_once "example/WxPay.JsApiPay.php";