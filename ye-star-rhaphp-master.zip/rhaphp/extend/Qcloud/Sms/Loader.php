<?php
/**
 * Created by PhpStorm.
 * User: Geeson myrhzq@qq.com
 * Date: 2017/8/9
 * Time: 下午5:59 中国·上海
 */
require "SmsSender.php";
require "SmsVoiceSender.php";